#### 53  1-Bit(黑白)
![](assets/tutorials/t53/1-bit.gif)

  这个主题很难，不过也是我很喜欢画的东西。学习1-bit的好处是，它对所有类型的像素画都很有帮助，比如：



![1bit](assets/tutorials/t53/1bit.png)

  我给“蔚蓝”画的这些小玩意本质上不算纯1-bit，但是了解1-bit的画法对我设计这些有很大帮助。

  下面是之前做的对这个主题有帮助的教程：
 - [关于低分辨率](https://kano.me/blog/my-thoughts-on-very-low-resolution)
 - [瓦片](related:42)
 - [轮廓线](related:49)
 - [像素画基础1](related:6)
 - [像素画基础2](related:35)
