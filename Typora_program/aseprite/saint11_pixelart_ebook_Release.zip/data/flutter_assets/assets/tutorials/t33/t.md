#### 33   岩石构成
![](assets/tutorials/t33/rocks.gif)

  第31个教程！

  这期不是个特别科学的教程，不过这一般是我画时候的思路。

  画岩石的主要建议是×找参考物×

  Pinterest或者google图片都是不错的地方。

  感谢大家支持！

> 风农：这节有soft highlight和stronger highlight这俩词，没找着哪里有参考，不知道这老哥是哪的口头禅吧，就按soft highlight->柔光这种翻译了，大概是这么个意思吧，领会精神(｀・ω・´)
 