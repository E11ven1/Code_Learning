#### 48  四足动物走/跑循环
![](assets/tutorials/t48/quadruped-walk.gif)

  这节估计是我做过的最复杂的教程之一了。如果你要学着画一个四足动物的行走循环，你需要先画一个两足的行走循环，再复制一份，然后把时间偏移25%左右，取决于你想要达到的风格。

  四足动物非常复杂，他们可以走，小跑，快跑，快走，还有其他很多的运动风格，每种都有完全不同的模式。

  这里是一些可以参考的连接：
 - [Cartoon Animation](https://www.amazon.com/Cartoon-Animation-Collectors-Preston-Blair/dp/1560100842/) 
 这本书里有很多例子（迪士尼风格动画书）
 - [Muybridge](https://www.amazon.com/Cartoon-Animation-Collectors-Preston-Blair/dp/1560100842/)
 这里有很多动物照片，如果你需要直接参考源头的话。
 - [Rocket 5 Studio](http://www.rocket5studios.com/tutorials/approaches-to-animating-quadrupeds-the-walk-cycles/)
（链接已经打不开了）
 
  希望对大家有帮助，感谢支持！