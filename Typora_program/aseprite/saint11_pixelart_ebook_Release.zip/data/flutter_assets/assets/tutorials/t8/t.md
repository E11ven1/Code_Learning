#### 8  专辑封面Ben Prunty  
![](assets/tutorials/t8/cover.gif)

  这是我给Ben Prunty最新专辑"ElectroCrypt"做的封面，都去听听，超赞，工作时候听特别好。

  [https://benprunty.bandcamp.com/album/electrocrypt](https://benprunty.bandcamp.com/album/electrocrypt)

  这张还是用Aseprite画的,源文件在下次art dump发。（patreon订阅之后可以下载aseprite工程源文件）