#### 25  像素画流程
![](assets/tutorials/t25/process.gif)
> 风农：这节图特别多，不过后面的静态图也都是动图里面的，只是拿出来，让大家慢慢看。动图后面9幅图都是定时特别长的，不是卡住了。

  今天的教程稍有不同。因为要说的是流程，我决定用更传统的序列的形式。

  带着定时阅读文字比较有压力，所以这个帖子我加了静态帧。

  感谢大家的支持，下节见。

![process1](assets/tutorials/t25/process-export1.png)

![process2](assets/tutorials/t25/process-export2.png)
![process3](assets/tutorials/t25/process-export3.png)
![process4](assets/tutorials/t25/process-export4.png)
![process5](assets/tutorials/t25/process-export5.png)
![process6](assets/tutorials/t25/process-export6.png)
![process7](assets/tutorials/t25/process-export7.png)
![process8](assets/tutorials/t25/process-export8.png)
![process9](assets/tutorials/t25/process-export9.png)
