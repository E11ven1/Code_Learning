#### 65  宇宙飞船设计
![](assets/tutorials/t65/spaceshipdesign.gif)

  设计宇宙飞船的时候我会遵循迭代的开发流程，如果某处不满意，我可以随时回退一步重新画。

  我强烈建议你看一下Arne的这篇文章：[spaceship_design](https://androidarts.com/spaceships/spaceship_design.htm)


  下面是其他几个对此有帮助的主题：
 - [宇宙飞船推进器](related:27)
 - [机器和怪异科技](related:21)
 - [星星](related:51)
 - [金属](related:39)
