#### 54  UI: The 9-Slice 9分
![](assets/tutorials/t54/9slice.gif)


  我决定把UI主题分成几个部分来讲，这是第一个。9分或者3分，我认为是任何UI的基本元素，是个不错的学习起点，你可以把它用在差不多任何地方。

  下面是我对9分和3分不同部分的叫法：

![9slicepost](assets/tutorials/t54/9slicename.gif)

 