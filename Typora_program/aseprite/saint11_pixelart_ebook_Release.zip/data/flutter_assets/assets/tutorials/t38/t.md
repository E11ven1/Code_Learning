#### 38  挤压和拉伸
![](assets/tutorials/t38/squeeze-stretch.gif)

  这节是最重要的动画原理之一：挤压和拉伸！跟动态模糊很相似，而且合起来用效果很好。

  要进一步学习这个的话，推荐看一下Alan Becker（已经入驻b站）的这个视频：
- [动画十二原则](https://www.bilibili.com/video/BV1x54y1e7J9)


  以及我之前的动态模糊教程：
- [动态模糊](related:37)
 
  感谢大家的支持
