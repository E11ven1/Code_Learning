#### 56  破坏物体
![](assets/tutorials/t56/broken.gif)

  这些是我画物体破坏动画时的一些准则。别忘了不同的材料会有不同的效果。

  其他一些对这个有帮助的教程：

  - [爆炸](related:20)
  - [火](related:13)
  - [烟雾](related:3)

  Thank's a lot for the support :)