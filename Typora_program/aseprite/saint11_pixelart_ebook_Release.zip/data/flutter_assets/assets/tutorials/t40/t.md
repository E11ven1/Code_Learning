#### 40  子弹
![](assets/tutorials/t40/bullet.gif)

  这期是关于子弹的！我从Vlambeer 的演讲里得到非常多灵感，十分推荐大家看。

- [屏幕震动的艺术](https://www.youtube.com/watch?v=AJdEqssNZ-U&t=2071s)
- [b站谜之声讲解版](https://www.bilibili.com/video/BV1Ds411v7Ux?p=1)


  画子弹时候参考其他游戏也很重要，比如合金弹头（Metal Slug）， 佣兵之王 （Mercenary Kings），挺进地牢（Enter the Gungeon），闪回（Flashback，应该是说育碧的，里面有写实的和隐形的子弹），废土之王（Nuclear Throne）。

  感谢大家的支持！

> 风农: 上面提到的讲座原视频里有段话特别有意思，大致是：
> 我们花很多心思在这些效果上，让玩家感觉自己是世界上最厉害的，即使他打的稀烂，但是他感觉还是很爽，我们会告诉他这游戏就是这么设计的。
