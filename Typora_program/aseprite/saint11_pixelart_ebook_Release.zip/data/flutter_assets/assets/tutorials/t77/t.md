#### 77 等轴透视

![Isometric](assets/tutorials/t77/isometric.gif)

  这期是关于等轴透视下的建议和技巧。这里加上“1”是因为我觉得这是个很大的主题，还有很大的探索空间。

  还有，可以看下这个超赞的[参考表](http://www.dennisbusch.de/knowhow.php)，对我做这期教程帮助非常大.

  感谢大家支持:)
