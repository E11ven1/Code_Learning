#### 50  简单的走路循环
![](assets/tutorials/t50/walkcycle.gif)

  这是我能想到最简单的走路循环了。我画成了12帧长，所以可以很容易的剪成6帧的。除了这个之外，其他的走路循环我都画成8帧 +2 （10帧）的，为了流畅性。

  图里我忘了加的一条建议：先集中在腿上，再考虑手臂，如果你在画画过程中感到困惑的话。

  如果需要更多参考，这本书是最佳之选：[原动画基础教程 (The Animator's Survival Kit)](https://www.bookdepository.com/Animators-Survival-Kit-Richard-E-Williams/9780571238347)  

> 风农：这本书真的是很厉害，也很有意思，不想看书的话还有配套的一套讲座，b站有搬运的，带字幕:  [配套视频](https://www.bilibili.com/video/BV1xW411i75S) 
​

其他对这个主题有帮助的教程:
 - [简单的跑步动画](related:5)
 - [俯视角跑步循环动画](related:7)
 - [动画计划](related:18)
 - [像素画流程](related:25)
 - [翅膀/飞行](related:31)
 - [四足动物走/跑循环](related:48)

