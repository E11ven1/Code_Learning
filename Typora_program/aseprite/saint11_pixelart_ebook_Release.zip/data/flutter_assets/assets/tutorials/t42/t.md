#### 42  制作瓦片
![](assets/tutorials/t42/tiles.gif)

  这期实在不太好做，希望我描述的不是太难懂。

  有些软件对画瓦片有帮助。

  Aseprite 有个功能叫："View > Tiled Mode > Tiled in Both Axes", 在画中间瓦片时非常有用。

  Pyxel Edit也有很多功能用来画复杂的瓦片集。
- [Aseprite](https://www.aseprite.org/)
- [Pyxel Edit](http://pyxeledit.com/)

> 风农: 使用aseprite的那个tiled in Both Axes就应该不需要偏移50了，因为上下左右显示的都是同样的瓦片，直接选个角改就行了。
