#### 78 俯视角攻击

![TopDownAttack](assets/tutorials/t78/topdownattack.gif)

  这节是我画俯视角攻击动画的思路。我只做了一个方向的，以后可能会试着加别的，不过我觉着没什么必要，都按一样的逻辑画就可以。把腿，躯干和头想象成叠起来的一堆，他们应该沿着攻击的方向滑。

  这里是其他几个相关的教程:
  - [俯视角跑步循环动画](related:7)
  - [俯视角走路循环动画](related:76)
  - [简单攻击动画](related:2)

  Thank you for the support <3


