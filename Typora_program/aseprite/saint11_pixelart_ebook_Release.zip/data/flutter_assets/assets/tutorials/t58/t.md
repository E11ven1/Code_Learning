#### 58  可爱
![](assets/tutorials/t58/cute.gif)

  这周的教程是关于画可爱的东西。

  画可爱的角色不是我的特长，不过还是写了点自己画可爱角色时的准则。记住达到可爱的效果有非常多的方法，这只是我通常的做法。

  Aaron Blaise 做过一期很棒的视频，可以看看：
 - [如何画的可爱](https://www.youtube.com/watch?v=9ByQoGs992Y&t=1434s)

  我之前关于画脸的教程也有点用：
 - [肖像](related:29)
