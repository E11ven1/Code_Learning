#### 49  轮廓线

![](assets/tutorials/t49/outline.gif)

  我一般不会在自己的像素画里用太多的轮廓线，因为我画的分辨率都非常低，除了黑色的外边。我会把这个外边放到几乎所有地方，有助于提高对比度和剪影效果。

之前的教程里还提到过线条的处理方式，可以看看：  
 - [像素画基础2](related:35)
 - [这个教程也可以看一看](https://kano.me/blog/my-thoughts-on-very-low-resolution)
 

感谢大家的支持！
