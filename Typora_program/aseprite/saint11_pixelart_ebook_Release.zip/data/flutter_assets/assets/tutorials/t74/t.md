#### 74 木头纹理

![](assets/tutorials/t74/wood.gif)

  这期是关于如何画木头纹理！

  木头不算是特别难画，但如果你想画的很细致，就会很耗时。我通常会先集中在大的形状上，如果满意了，再去处理纹理。不然可能就会浪费时间在一个不满意的形状上画了纹理，然后不得不重新画一遍。

  下面是其他几个有帮助的教程：
 - [植物1](related:15)
 - [植物2](related:34)
 - [植物3](related:59)

  pillow shading ：

![](assets/tutorials/t74/pillowshading.png)
