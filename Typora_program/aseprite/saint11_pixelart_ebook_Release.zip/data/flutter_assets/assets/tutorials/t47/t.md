#### 47  阴影
![](assets/tutorials/t47/shade.gif)

  以上这些简单的建议都是关于如何画阴影，以及如何避免模糊的枯燥的阴影。

  色相偏移，色带压缩都是很简单有效的处理方式。

  如果想更深入的了解颜色，可以看看这个超赞的教程：
 - [颜色](http://www.writedesignonline.com/resources/design/rules/color.html)
