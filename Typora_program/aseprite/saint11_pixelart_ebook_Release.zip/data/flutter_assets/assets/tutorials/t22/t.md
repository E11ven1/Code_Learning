#### 22   视差和深度

![parallaxanddepth](assets/tutorials/t22/parallaxanddepth.gif)

视差是游戏和编程里我很喜欢的技术。非常好实现，是2d游戏里表现深度的好办法。

我还附带了一个.love的例子，包括一个.lua的源代码文件，你可以看看。

要运行.love文件，需要先下载Löve： <https://love2d.org/>

[parallax.love](https://www.patreon.com/file?h=7863658&i=795078)

[main.lua](https://www.patreon.com/file?h=7863658&i=795082)

> 这一期跟后面有几期他都用到了这个叫love的引擎，我完全没用过，所以大家就领会领会精神就好了，如果感兴趣也可以去研究一下。
